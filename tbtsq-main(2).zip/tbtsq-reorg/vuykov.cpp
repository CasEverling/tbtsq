#include "vuykov.hpp"

// ── enqueue ───────────────────────────────────────────────────────────────────
//
// 1. Atomically claim the next tail slot with fetch_add.
//    Multiple producers can race here; each gets a unique index.
//
// 2. Spin until the slot's ready flag is CLEARED (empty).
//    A slow consumer may still be reading the previous lap's data at this
//    index, so we wait rather than overwrite.
//
// 3. Write data via move semantics — no copy constructor is invoked,
//    so types that are move-only (or where copying throws) are safe.
//
// 4. Set the ready flag (test_and_set) to signal the slot is full.
//    The release ordering pairs with the acquire in dequeue so the
//    consumer sees the fully constructed data.
//
template<typename T>
void VuykovQueue<T>::enqueue(T&& val) {
    const size_t slot = tail.fetch_add(1, std::memory_order_relaxed) % capacity;
    Node& node = ring[slot];

    // Spin while the slot is still occupied (ready flag is SET).
    // This back-pressures producers when the ring is full.
    while (node.ready.test(std::memory_order_acquire)) {
        _mm_pause();
    }

    // Move the value in — avoids any potentially-throwing copy.
    node.data = std::make_shared<T>(std::move(val));

    // Publish: flag transitions cleared → set.
    node.ready.test_and_set(std::memory_order_release);
}

// ── dequeue ───────────────────────────────────────────────────────────────────
//
// 1. Atomically claim the next head slot with fetch_add.
//    Multiple consumers can race here; each gets a unique index.
//
// 2. Check whether the slot is full (ready flag SET).
//    If the ring is empty we return false immediately — no spinning,
//    matching the non-blocking contract of BaseQueue::dequeue.
//
// 3. Move the shared_ptr out into retVal and clear the node's data.
//    Clearing the shared_ptr releases the reference held by the slot
//    so the slot is truly empty for the next producer lap.
//
// 4. Clear the ready flag (acquire+release) to signal the slot is empty.
//    The release pairs with the acquire spin in enqueue.
//
template<typename T>
bool VuykovQueue<T>::dequeue(std::shared_ptr<T>& retVal) {
    const size_t slot = head.fetch_add(1, std::memory_order_relaxed) % capacity;
    Node& node = ring[slot];

    // Non-blocking: if the slot is empty, report miss.
    if (!node.ready.test(std::memory_order_acquire)) {
        // Give the slot back — undo the cursor advance so another
        // consumer (or a retry) can pick it up.
        head.fetch_sub(1, std::memory_order_relaxed);
        return false;
    }

    // Claim the data via move — the shared_ptr's ref count is not bumped,
    // ownership transfers directly to the caller.
    retVal     = std::move(node.data);
    node.data  = nullptr;

    // Unpublish: flag transitions set → cleared, slot is now writable.
    node.ready.clear(std::memory_order_release);

    return true;
}
