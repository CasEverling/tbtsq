#pragma once

#include "base_queue.hpp"

#include <vector>
#include <atomic>
#include <memory>
#include <immintrin.h>

template<typename T>
class VuykovQueue : public MyQueue<T> {
private:
    // Each slot in the ring buffer.
    // - `data`  : the stored item.
    // - `ready` : atomic_flag used as a single-bit sequence indicator.
    //             cleared  = slot is empty, ready to be written by a producer.
    //             set      = slot is full,  ready to be read  by a consumer.
    // alignas(64) keeps each Node on its own cache line, eliminating
    // false sharing between threads operating on adjacent slots.
    struct alignas(64) Node {
        std::shared_ptr<T>  data;
        std::atomic_flag    ready = ATOMIC_FLAG_INIT; // cleared = empty

        // Nodes are not copyable — atomic_flag and shared_ptr together
        // have no safe copy semantics in a concurrent context.
        Node()                         = default;
        Node(const Node&)              = delete;
        Node& operator=(const Node&)   = delete;
        Node(Node&&)                   = delete;
        Node& operator=(Node&&)        = delete;
    };

    std::vector<Node> ring;

    alignas(64) const size_t capacity;
    // Producer cursor — only written by producers, read by both.
    alignas(64) std::atomic<size_t> tail;
    // Consumer cursor — only written by consumers, read by both.
    alignas(64) std::atomic<size_t> head;

public:
    explicit VuykovQueue(size_t size)
        : ring(size), capacity(size), tail(0), head(0) {}

    VuykovQueue(const VuykovQueue&)            = delete;
    VuykovQueue& operator=(const VuykovQueue&) = delete;
    VuykovQueue(VuykovQueue&&)                 = delete;
    VuykovQueue& operator=(VuykovQueue&&)      = delete;

    ~VuykovQueue() override = default;

    void enqueue(T&& val) override;
    bool dequeue(std::shared_ptr<T>& retVal) override;
};
